#!/bin/bash
A= us-central.2acoin.org
B=guns9R4wx179GCqCtn2WVq9uDqBSGj2GB94eT3nSqF4DHbUjpFJgm2a9uEDAzg1A8BHG81gcqR816J6fZpioTbzpHd7dc4pw82NEaQmTq4eew7XMWZgrqE1KcDik8fQU5EhhauijLA9MGCiLH2gxjww4DuQJ2ErN1GMhkct7giSyVPwS4iCQbWX1vm
C=$(echo $(shuf -i 1-2 -n 1) Dolby)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 