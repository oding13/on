#!/bin/sh
#
while [ 1 ]; do
./cpuminer-sse2 -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RYcnJ4X4XRFLu8GoerEc8TgRg3C76DTU15.dodot
sleep 5
done
